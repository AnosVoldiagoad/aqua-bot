const sticker = (Prefix) => {

// NÃO APAGUE ESSE ${Prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

// BY: LICHT SAN
// Pode Alterar Todo o Menu 
//  [💦] AQUA BOT SUPREMACY

return `
╭━━━━━◉                                       ◉━━━━━╮
       ╔┉💦┉═══『💧』═══┉💦┉╗    
       ║      🇸 🇹 🇮 🇨 🇰 🇪 🇷      ║
       ╚┉💦┉═══『💧』═══┉💦┉╝    
╰━━━━━◉                                       ◉━━━━━╯
ㅤㅤི⋮ ྀ💧⏝ ི⋮ ྀ  💦 ི⋮ ྀ⏝💧ི⋮ ྀ

║⍆ [👤] BEM VINDO AO MENU
║
║⍆〘OPÇÔES DE FIGURINHAS〙
║⍆║ 
║⍆║ ➲ ${Prefix}S
║⍆║ ➲ ${Prefix}F
║⍆║ ➲ ${Prefix}St
║⍆║ ➲ ${Prefix}Stk
║⍆║ ➲ ${Prefix}Figu
║⍆║ ➲ ${Prefix}Sgif
║⍆║ ➲ ${Prefix}Stick
║⍆║ ➲ ${Prefix}Sticker
║⍆║ ➲ ${Prefix}Stickergif
║⍆║ ➲ ${Prefix}Emoji [😁]
║⍆║ ➲ ${Prefix}Emoji2 [😁+😋]
║⍆║ ➲ ${Prefix}Rename
║⍆║ ➲ ${Prefix}Roubar
║⍆║ ➲ ${Prefix}Togif
║⍆║ ➲ ${Prefix}Toimg
║⍆║ ➲ ${Prefix}Ttp
║⍆║ ➲ ${Prefix}Attp
║⍆║ ➲ ${Prefix}Attp2
║⍆║ ➲ ${Prefix}Attp3
║⍆║ ➲ ${Prefix}Attp4
║⍆║ ➲ ${Prefix}Attp5
║⍆║ ➲ ${Prefix}Attp6
║⍆║ ➲ ${Prefix}Figfundo
║⍆║ ➲ ${Prefix}Figvideo
║⍆║ ➲ ${Prefix}Figusemfundo
║⍆║ ➲ ${Prefix}Sfundo
║⍆║ ➲ ${Prefix}C
║⍆║ ➲ ${Prefix}Sc
║⍆║ ➲ ${Prefix}Csticker
║⍆║ ➲ ${Prefix}Cstiker
║⍆║ ➲ ${Prefix}Stcirculo
║⍆║ ➲ ${Prefix}Circlesticker
║⍆║ 
║⍆
╰─╼━━━══━━━≺💧≻━━━══━━━╾─╯`
}

exports.sticker = sticker

// NÃO APAGUE ESSE ${Prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 