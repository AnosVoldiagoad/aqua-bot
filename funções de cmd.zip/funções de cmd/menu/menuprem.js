const menuprem = (prefix) => { 

// NÃO APAGUE ESSE ${Prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

// BY: LICHT SAN
// Pode Alterar Todo o Menu 
//  [💦] AQUA BOT SUPREMACY

return `
╭━━━━━◉                                       ◉━━━━━╮
       ╔┉💦┉═══『💧』═══┉💦┉╗    
       ║   🇵 🇷 🇪 🇲 🇮 🇺 🇲        ║
       ╚┉💦┉═══『💧』═══┉💦┉╝    
╰━━━━━◉                                       ◉━━━━━╯
ㅤㅤི⋮ ྀ💧⏝ ི⋮ ྀ  💦 ི⋮ ྀ⏝💧ི⋮ ྀ

║⍆ [👤] BEM VINDO AO MENU
║
║⍆ㅤㅤ〘OPÇÔES DE PREMIUM〙
║⍆║ 
║⍆║ ➲ ${prefix}Correio
║⍆║ ➲ ${prefix}Delete
║⍆║ ➲ ${prefix}Gerar-CPF
║⍆║ ➲ ${prefix}Cep
║⍆║ ➲ ${prefix}Placa
║⍆║ ➲ ${prefix}DDD
║⍆║ ➲ ${prefix}EncurtarLink
║⍆║ ➲ ${prefix}Destrava 
║⍆║ ➲ ${prefix}Hentai-Neko
║⍆║ ➲ ${prefix}Hentai
║⍆║ ➲ ${prefix}Porno
║⍆║ ➲ ${prefix}Premiumlist
║⍆║ ➲ ${prefix}Desbanir [Número] 
║⍆║ ➲ ${prefix}Get
║⍆║ ➲ ${prefix}Lyrics
║⍆║ ➲ ${prefix}Docfake
║⍆║ ➲ ${prefix}GanharXP
║⍆║ ➲ ${prefix}GerarGP
║⍆║ ➲ ${prefix}Pix
║⍆║ 
║⍆
╰─╼━━━══━━━≺💧≻━━━══━━━╾─╯`
}

exports.menuprem = menuprem