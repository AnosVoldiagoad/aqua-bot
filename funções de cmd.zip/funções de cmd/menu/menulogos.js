const menulogos = (Prefix ) => {
  
// NÃO APAGUE ESSE ${Prefix }, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.  
  
  return `​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
  ╭━━━━━◉                                       ◉━━━━━╮
       ╔┉💦┉═══『💧』═══┉💦┉╗    
       ║ㅤㅤ  🇲 🇪 🇸 🇹 🇷 🇪ㅤㅤ║
       ╚┉💦┉═══『💧』═══┉💦┉╝    
╰━━━━━◉                                       ◉━━━━━╯
ㅤㅤི⋮ ྀ💧⏝ ི⋮ ྀ  💦 ི⋮ ྀ⏝💧ི⋮ ྀ

║⍆ [👤] BEM VINDO AO MENU
║
║⍆ㅤㅤ〘OPÇÔES DE LOGOS〙
║⍆║ 
║⍆║ ➲  ${Prefix }Plaq
║⍆║ ➲  ${Prefix }Plaq2
║⍆║ ➲  ${Prefix }Plaq3
║⍆║ ➲  ${Prefix }Plaq4
║⍆║ ➲  ${Prefix }Plaq5
║⍆║ ➲  ${Prefix }Comporn (txt/txt]
║⍆║ ➲  ${Prefix }Glitch (txt/txt]
║⍆║ ➲  ${Prefix }Glitch3 (txt/txt]
║⍆║ ➲  ${Prefix }Grafity (txt-txt]
║⍆║ ➲  ${Prefix }Space (txt/txt]
║⍆║ ➲  ${Prefix }Marvel (txt/txt]
║⍆║ ➲  ${Prefix }GamePlay (txt/txt]
║⍆║ ➲  ${Prefix }Stone (txt/txt]
║⍆║ ➲  ${Prefix }Steel (txt/txt]
║⍆║ ➲  ${Prefix }Ffbanner (txt/txt]
║⍆║ ➲  ${Prefix }Mascoteavatar (txt/txt]
║⍆║ ➲  ${Prefix }Txtquadrinhos (txt]
║⍆║ ➲  ${Prefix }HackNeon (txt]
║⍆║ ➲  ${Prefix }EquipeMascote (txt]
║⍆║ ➲  ${Prefix }FFavatar (txt]
║⍆║ ➲  ${Prefix }Gizquadro (txt]
║⍆║ ➲  ${Prefix }Angelglx (txt]
║⍆║ ➲  ${Prefix }WingEffect (txt]
║⍆║ ➲  ${Prefix }Angelwing (txt]
║⍆║ ➲  ${Prefix }Blackpink (txt]
║⍆║ ➲  ${Prefix }Girlmascote (txt]
║⍆║ ➲  ${Prefix }Mascotegame (txt]
║⍆║ ➲  ${Prefix }Fpsmascote (txt]
║⍆║ ➲  ${Prefix }Logogame (txt]
║⍆║ ➲  ${Prefix }Glitch2 (txt]
║⍆║ ➲  ${Prefix }3DGold (txt]
║⍆║ ➲  ${Prefix }Placaloli (txt]
║⍆║ ➲  ${Prefix }Phadow (txt]
║⍆║ ➲  ${Prefix }Efeitoneon (txt]
║⍆║ ➲  ${Prefix }Cemiterio (txt]
║⍆║ ➲  ${Prefix }Metalgold (txt]
║⍆║ ➲  ${Prefix }Narutologo (txt]
║⍆║ ➲  ${Prefix }Fire (txt]
║⍆║ ➲  ${Prefix }Romantic (txt]
║⍆║ ➲  ${Prefix }Smoke (txt]
║⍆║ ➲  ${Prefix }Papel (txt]
║⍆║ ➲  ${Prefix }Lovemsg (txt]
║⍆║ ➲  ${Prefix }Lovemsg2 (txt]
║⍆║ ➲  ${Prefix }Lovemsg3 (txt]
║⍆║ ➲  ${Prefix }Coffecup (txt]
║⍆║ ➲  ${Prefix }Coffecup2 (txt]
║⍆║ ➲  ${Prefix }Cup (txt]
║⍆║ ➲  ${Prefix }Florwooden (txt]
║⍆║ ➲  ${Prefix }Lobometal (txt]
║⍆║ ➲  ${Prefix }Harryp (txt]
║⍆║ ➲  ${Prefix }Txtborboleta (txt]
║⍆║ ➲  ${Prefix }Madeira (txt]
║⍆║ ➲  ${Prefix }Pornhub (txt]
║⍆║ ➲  ${Prefix }Escudo (txt]
║⍆║ ➲  ${Prefix }Transformer (txt]
║⍆║ ➲  ${Prefix }America (txt]
║⍆║ ➲  ${Prefix }Demongreen (txt]
║⍆║ ➲  ${Prefix }Wetglass (txt] 
║⍆║ ➲  ${Prefix }Toxic (txt]
║⍆║ ➲  ${Prefix }Neon3 (txt]
║⍆║ ➲  ${Prefix }Neondevil (txt]
║⍆║ ➲  ${Prefix }Neongreen (txt]
║⍆║ ➲  ${Prefix }Lava (txt]
║⍆║ ➲  ${Prefix }Halloween (txt]
║⍆║ ➲  ${Prefix }Neondevil (txt]
║⍆║ ➲  ${Prefix }DemonFire (txt]
║⍆║ ➲  ${Prefix }DemonGreen (txt]
║⍆║ ➲  ${Prefix }Thunderv2 (txt]
║⍆║ ➲  ${Prefix }Thunder (txt]
║⍆║ ➲  ${Prefix }Colaq (txt]
║⍆║ ➲  ${Prefix }Luxury (txt]
║⍆║ ➲  ${Prefix }Berry (txt]
║⍆║ ➲  ${Prefix }Transformer (txt]
║⍆║ ➲  ${Prefix }Matrix (txt]
║⍆║ ➲  ${Prefix }Horror (txt]
║⍆║ ➲  ${Prefix }Nuvem (txt]
║⍆║ ➲  ${Prefix }Neon (txt]
║⍆║ ➲  ${Prefix }Neon1 (txt]
║⍆║ ➲  ${Prefix }Neon2 (txt]
║⍆║ ➲  ${Prefix }Neon3d (txt]
║⍆║ ➲  ${Prefix }NeonGreen (txt]
║⍆║ ➲  ${Prefix }Neon3 (txt]
║⍆║ ➲  ${Prefix }Neve (txt]
║⍆║ ➲  ${Prefix }Areia (txt]
║⍆║ ➲  ${Prefix }Vidro (txt]
║⍆║ ➲  ${Prefix }Style (txt]
║⍆║ ➲  ${Prefix }Pink (txt]
║⍆║ ➲  ${Prefix }Carbon (txt]
║⍆║ ➲  ${Prefix }Tetalblue (txt]
║⍆║ ➲  ${Prefix }Toxic (txt]
║⍆║ ➲  ${Prefix }Jeans (txt]
║⍆║ ➲  ${Prefix }Ossos (txt]
║⍆║ ➲  ${Prefix }Asfalto (txt]
║⍆║ ➲  ${Prefix }Natal (txt]
║⍆║ ➲  ${Prefix }Joker (txt]
║⍆║ ➲  ${Prefix }Blood (txt]
║⍆║ ➲  ${Prefix }Break (txt]
║⍆║ ➲  ${Prefix }Fiction (txt]
║⍆║ ➲  ${Prefix }3dstone (txt]
║⍆║ ➲  ${Prefix }Lapis (txt]
║⍆║ ➲  ${Prefix }Gelo (txt]
║⍆║ ➲  ${Prefix }Rainbow (txt]
║⍆║ ➲  ${Prefix }Metalfire (txt] 
║⍆║ 
║⍆
╰─╼━━━══━━━≺💧≻━━━══━━━╾─╯`
}

exports.menulogos = menulogos

// NÃO APAGUE ESSE ${Prefix }, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 