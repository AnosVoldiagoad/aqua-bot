const menuadm = (Prefix, pushname, numerodn, tempo, isGroup, groupName, NomeDoBot ) => {

return `
╭━━━━━◉                                       ◉━━━━━╮
       ╔┉💦┉═══『💧』═══┉💦┉╗    
       ║ㅤㅤㅤㅤ🇦  🇩  🇲  🇸ㅤㅤ    ║
       ╚┉💦┉═══『💧』═══┉💦┉╝    
╰━━━━━◉                                       ◉━━━━━╯
ㅤㅤི⋮ ྀ💧⏝ ི⋮ ྀ  💦 ི⋮ ྀ⏝💧ི⋮ ྀ

║⍆ [👤] BEM VINDO AO MENU
║
║⍆〘OPÇÔES DE ADMINISTRAÇÃO〙
║⍆║ 
║⍆║ ➲ ${Prefix}Tagall [Tag Todos]
║⍆║ ➲ ${Prefix}Marcar [@ Todos]
║⍆║ ➲ ${Prefix}Resetaki [Akinator]
║⍆║ ➲ ${Prefix}AutoSticker [1-0]
║⍆║ ➲ ${Prefix}Hidetag [Tag Todos] 
║⍆║ ➲ ${Prefix}Aquah 1-0]
║⍆║ ➲ ${Prefix}Aqua2 [1-0]
║⍆║ ➲ ${Prefix}Descgp
║⍆║ ➲ ${Prefix}Nomegp
║⍆║ ➲ ${Prefix}Fotogp
║⍆║ ➲ ${Prefix}Ban
║⍆║ ➲ ${Prefix}Reviver [Marcar Msg]
║⍆║ ➲ ${Prefix}Kick [@Alvo]
║⍆║ ➲ ${Prefix}Marcarwa [Wa.Me Todos] 
║⍆║ ➲ ${Prefix}Add [Número]
║⍆║ ➲ ${Prefix}Linkgp
║⍆║ ➲ ${Prefix}Promover [@Alvo]
║⍆║ ➲ ${Prefix}Rebaixar [@Alvo]
║⍆║ ➲ ${Prefix}Tirardalista
║⍆║ ➲ ${Prefix}Listanegra
║⍆║ ➲ ${Prefix}Listban
║⍆║ ➲ ${Prefix}Mute [@Alvo]
║⍆║ ➲ ${Prefix}Desmute [@Alvo]
║⍆║ ➲ ${Prefix}Mutados
║⍆║ ➲ ${Prefix}Autoban
║⍆║ ➲ ${Prefix}Kickfake [Remove  Fakes]
║⍆║ ➲ ${Prefix}Banfake [Remove  Fakes]
║⍆║
║
║⍆ㅤㅤ  ㅤ 〘CONFIGURAÇÃO〙
║
║⍆║
║⍆║ ➲ ${Prefix}Autofig-PV [1-0]
║⍆║ ➲ ${Prefix}Autofig-Autofig-GP [1-0]
║⍆║ ➲ ${Prefix}Configp
║⍆║ ➲ ${Prefix}Timegrup
║⍆║ ➲ ${Prefix}Antidocumento [1-0]
║⍆║ ➲ ${Prefix}Antilinkhard [1-0]
║⍆║ ➲ ${Prefix}Antilink [1-0]
║⍆║ ➲ ${Prefix}Antiloc [1-0]
║⍆║ ➲ ${Prefix}Anticontato [1-0]
║⍆║ ➲ ${Prefix}Antiaudio [1-0]
║⍆║ ➲ ${Prefix}Antivideo [1-0]
║⍆║ ➲ ${Prefix}Antifake [1-0]
║⍆║ ➲ ${Prefix}Antiimg [1-0]
║⍆║ ➲ ${Prefix}AntiCatalogo [1-0]
║⍆║ ➲ ${Prefix}Antisticker [1-0]
║⍆║ ➲ ${Prefix}Nsfw [1-0]
║⍆║ ➲ ${Prefix}Leveling [1-0]
║⍆║ ➲ ${Prefix}Anagrama [1-0]
║⍆║ ➲ ${Prefix}AutoReact [1-0]
║⍆║ ➲ ${Prefix}Legendabv2
║⍆║ ➲ ${Prefix}Legendasaiu2
║⍆║ ➲ ${Prefix}Bemvindo2
║⍆║ ➲ ${Prefix}Sairgp
║⍆║ ➲ ${Prefix}Lembrete
║⍆║ ➲ ${Prefix}Sorteio [Qualquer Coisa]
║⍆║ ➲ ${Prefix}SorteioNumeros [Qualquer Coisa]
║⍆║ ➲ ${Prefix}Infogp
║⍆║ ➲ ${Prefix}Abrirgp
║⍆║ 
║⍆
╰─╼━━━══━━━≺💧≻━━━══━━━╾─╯`
}

exports.menuadm = menuadm