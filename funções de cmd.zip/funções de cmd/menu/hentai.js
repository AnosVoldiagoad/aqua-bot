const menuhentai = (Prefix) => {

// NÃO APAGUE ESSE ${Prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

// BY: LICHT SAN
// Pode Alterar Todo o Menu 
//  [💦] AQUA BOT SUPREMACY

return `
╭━━━━━◉                                       ◉━━━━━╮
       ╔┉💦┉═══『💧』═══┉💦┉╗    
       ║      🇭 🇪 🇳 🇹 🇦 🇮 🇸      ║
       ╚┉💦┉═══『💧』═══┉💦┉╝    
╰━━━━━◉                                       ◉━━━━━╯
ㅤㅤི⋮ ྀ💧⏝ ི⋮ ྀ  💦 ི⋮ ྀ⏝💧ི⋮ ྀ

║⍆ [👤] BEM VINDO AO MENU
║
║⍆〘OPÇÔES DE HENTAI〙
║⍆║ 
║⍆║ ➲ ${Prefix}HentaiList
║⍆║ ➲ ${Prefix}Ahegao
║⍆║ ➲ ${Prefix}Loli
║⍆║ ➲ ${Prefix}Ass
║⍆║ ➲ ${Prefix}Bdsm
║⍆║ ➲ ${Prefix}Blowjob
║⍆║ ➲ ${Prefix}Cuckold
║⍆║ ➲ ${Prefix}Cum
║⍆║ ➲ ${Prefix}Ero
║⍆║ ➲ ${Prefix}Femdom
║⍆║ ➲ ${Prefix}Foot
║⍆║ ➲ ${Prefix}Glasses
║⍆║ ➲ ${Prefix}Hentai3
║⍆║ ➲ ${Prefix}Hentai2
║⍆║ ➲ ${Prefix}Hentai
║⍆║ ➲ ${Prefix}Jahy
║⍆║ ➲ ${Prefix}Orgy
║⍆║ ➲ ${Prefix}Neko
║⍆║ ➲ ${Prefix}Tentacles
║⍆║ ➲ ${Prefix}Thighs
║⍆║ ➲ ${Prefix}Yuri
║⍆║ ➲ ${Prefix}Mia
║⍆║ 
║⍆
╰─╼━━━══━━━≺💧≻━━━══━━━╾─╯`
}

exports.menuhentai = menuhentai

// NÃO APAGUE ESSE ${Prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 