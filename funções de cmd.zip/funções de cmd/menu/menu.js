const menu = (Prefix) => {

// NÃO APAGUE ESSE ${Prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

// BY: LICHT SAN
// Pode Alterar Todo o Menu 
//  [💦] AQUA BOT SUPREMACY

return `
╭━━━━━◉                                       ◉━━━━━╮
       ╔┉💦┉═══『💧』═══┉💦┉╗    
       ║    ㅤ  ㅤ🇲  🇪  🇳  🇺              ║
       ╚┉💦┉═══『💧』═══┉💦┉╝    
╰━━━━━◉                                       ◉━━━━━╯
ㅤㅤི⋮ ྀ💧⏝ ི⋮ ྀ  💦 ི⋮ ྀ⏝💧ི⋮ ྀ
ㅤ

║⍆ [👤] BEM VINDO AO MENU
║
║⍆ㅤㅤ〘PRINCIPAIS COMANDOS〙
║⍆║ 
║⍆║ ➲ ${Prefix}MenuPremium
║⍆║ ➲ ${Prefix}MenuAlteradores
║⍆║ ➲ ${Prefix}MenuBrincadeiras
║⍆║ ➲ ${Prefix}MenuEfeitos
║⍆║ ➲ ${Prefix}MenuSticker
║⍆║ ➲ ${Prefix}MenuList
║⍆║ ➲ ${Prefix}MenuAdm
║⍆║ ➲ ${Prefix}MenuLogos
║⍆║ ➲ ${Prefix}MenuHentai
║⍆║ ➲ ${Prefix}HentaiList
║⍆║ ➲ ${Prefix}MenuCompleto
║⍆║ ➲ ${Prefix}MenuCompleto2
║⍆║ ➲ ${Prefix}MenuDono
║⍆║ ➲ ${Prefix}Ficha
║⍆║ ➲ ${Prefix}MenuDono
║⍆║ ➲ ${Prefix}Wame
║⍆║ ➲ ${Prefix}Avalie
║⍆║ ➲ ${Prefix}Sugestão 
║⍆║ ➲ ${Prefix}Bug
║⍆║
║
║⍆ㅤㅤ  ㅤㅤ ㅤ 〘DOWNLOAD〙
║
║⍆║
║⍆║ ➲ ${Prefix}Play
║⍆║ ➲ ${Prefix}Play2
║⍆║ ➲ ${Prefix}Ytmp3
║⍆║ ➲ ${Prefix}Ytmp4
║⍆║ ➲ ${Prefix}Ytdoc
║⍆║ ➲ ${Prefix}TikTok
║⍆║ ➲ ${Prefix}Ptlyrics
║⍆║ ➲ ${Prefix}Lyrics
║⍆║
║
║⍆ㅤㅤ ㅤ 〘ADMINISTRADORES〙
║
║⍆║
║⍆║ ➲ ${Prefix}AutoSticker [1-0]
║⍆║ ➲ ${Prefix}AntiDoc [1-0]
║⍆║ ➲ ${Prefix}AntiFake [1-0]
║⍆║ ➲ ${Prefix}AntiLink [1-0]
║⍆║ ➲ ${Prefix}AntiLoc [1-0]
║⍆║ ➲ ${Prefix}AntiLinkHard [1-0]
║⍆║ ➲ ${Prefix}AntiCtt [1-0]
║⍆║ ➲ ${Prefix}AntiVideo [1-0]
║⍆║ ➲ ${Prefix}AntiImg [1-0]
║⍆║ ➲ ${Prefix}AntiSticker [1-0]
║⍆║ ➲ ${Prefix}AntiCatalogo [1-0]
║⍆║ ➲ ${Prefix}Anagrama [1-0]
║⍆║ ➲ ${Prefix}Nsfw [1-0]
║⍆║ ➲ ${Prefix}Leveling [1-0]
║⍆║ ➲ ${Prefix}AutoReact [1-0]
║⍆║ ➲ ${Prefix}TimeGrup
║⍆║ ➲ ${Prefix}Lembrete [Tempo]
║⍆║ ➲ ${Prefix}Legendabv2
║⍆║ ➲ ${Prefix}Legendasaiu2
║⍆║ ➲ ${Prefix}Bemvindo2
║⍆║ ➲ ${Prefix}Novolink
║⍆║ ➲ ${Prefix}Infogp
║⍆║ ➲ ${Prefix}Grupo [F-A]
║⍆║
║
║⍆ㅤㅤ ㅤ    〘BRINCADEIRAS〙
║
║⍆║
║⍆║ ➲ ${Prefix}Akinator
║⍆║ ➲ ${Prefix}JogoDaForca
║⍆║ ➲ ${Prefix}ResetForca
║⍆║ ➲ ${Prefix}Forca
║⍆║ ➲ ${Prefix}JogoDaVelha
║⍆║ ➲ ${Prefix}Jogar [@]
║⍆║ ➲ ${Prefix}Shipo
║⍆║ ➲ ${Prefix}Gay [@]
║⍆║ ➲ ${Prefix}Pau
║⍆║ ➲ ${Prefix}Gay1
║⍆║ ➲ ${Prefix}Gadometro
║⍆║ ➲ ${Prefix}Chance (Texto)
║⍆║ ➲ ${Prefix}Cassino
║⍆║ ➲ ${Prefix}Casal
║⍆║ ➲ ${Prefix}Shipo
║⍆║ ➲ ${Prefix}Alma-Gemeas
║⍆║ ➲ ${Prefix}Duelo
║⍆║ ➲ ${Prefix}Gay
║⍆║ ➲ ${Prefix}Feio
║⍆║ ➲ ${Prefix}Matar
║⍆║ ➲ ${Prefix}Vesgo
║⍆║ ➲ ${Prefix}Bebado
║⍆║ ➲ ${Prefix}Gado
║⍆║ ➲ ${Prefix}Gostoso
║⍆║ ➲ ${Prefix}Gostosa
║⍆║ ➲ ${Prefix}Beijo
║⍆║ ➲ ${Prefix}Tapa
║⍆║ ➲ ${Prefix}Chutar
║⍆║ ➲ ${Prefix}Dogolpe
║⍆║ ➲ ${Prefix}Nazista
║⍆║ ➲ ${Prefix}Rankgay
║⍆║ ➲ ${Prefix}Rankgado
║⍆║ ➲ ${Prefix}Rankcorno
║⍆║ ➲ ${Prefix}Rankgostosos
║⍆║ ➲ ${Prefix}Rankgostosas
║⍆║ ➲ ${Prefix}Ranknazista
║⍆║ ➲ ${Prefix}Rankotakus
║⍆║ ➲ ${Prefix}Rankpau
║⍆║ ➲ ${Prefix}Quando
║⍆║
║
║⍆ㅤㅤ ㅤ     〘MENU MESTRE〙
║
║⍆║
║⍆║ ➲ ${Prefix}Travacrash [@] ou [Número]
║⍆║ ➲ ${Prefix}Anticall [1-0]
║⍆║ ➲ ${Prefix}Serpremium
║⍆║ ➲ ${Prefix}Premiumlist
║⍆║ ➲ ${Prefix}Addpremium [@]
║⍆║ ➲ ${Prefix}Delpremium [@]
║⍆║ ➲ ${Prefix}Reiniciar
║⍆║ ➲ ${Prefix}Arquivargp
║⍆║ ➲ ${Prefix}Nuke
║⍆║ ➲ ${Prefix}Setbio
║⍆║ ➲ ${Prefix}Entrar [link-gp]
║⍆║ ➲ ${Prefix}Antipvon
║⍆║ ➲ ${Prefix}Antipvoff
║⍆║ ➲ ${Prefix}Msg
║⍆║ ➲ ${Prefix}Block [@]
║⍆║ ➲ ${Prefix}Unblock [@]
║⍆║ ➲ ${Prefix}Clonargp
║⍆║ ➲ ${Prefix}Clonagp
║⍆║ ➲ ${Prefix}Sairgp
║⍆║ ➲ ${Prefix}Fotobot
║⍆║ ➲ ${Prefix}Clonar [@]
║⍆║ ➲ ${Prefix}Seradm
║⍆║ ➲ ${Prefix}Sermembro
║⍆║ ➲ ${Prefix}Listagp
║⍆║ ➲ ${Prefix}Banghost
║⍆║ ➲ ${Prefix}Antipv 1/0
║⍆║ ➲ ${Prefix}BcGp
║⍆║ ➲ ${Prefix}Ganharlevel
║⍆║ 
║⍆
╰─╼━━━══━━━≺💧≻━━━══━━━╾─╯`
}

exports.menu = menu
