const brincadeiras = (Prefix) => {

// NÃO APAGUE ESSE ${Prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

// BY: LICHT SAN
// Pode Alterar Todo o Menu 
//  [💦] AQUA BOT SUPREMACY

return `
╭━━━━━◉                                         ◉━━━━━╮
   ╔┉💦┉═══    『  💧  』      ═══┉💦┉╗    
   ║🇧 🇷 🇮 🇳 🇨 🇦 🇩 🇪 🇮 🇷 🇦║
   ╚┉💦┉═══    『  💧    』    ═══┉💦┉╝    
╰━━━━━◉                                         ◉━━━━━╯
ㅤㅤི⋮ ྀ💧⏝ ི⋮ ྀ  💦 ི⋮ ྀ⏝💧ི⋮ ྀ


║⍆ [👤] BEM VINDO AO MENU
║
║⍆〘OPÇÔES DE BRINCADEIRAS〙
║⍆║ 
║⍆║ ➲ ${Prefix}Duelo
║⍆║ ➲ ${Prefix}Level
║⍆║ ➲ ${Prefix}Ranklevel
║⍆║ ➲ ${Prefix}Arma
║⍆║ ➲ ${Prefix}Resetaki
║⍆║ ➲ ${Prefix}Simih
║⍆║ ➲ ${Prefix}Simih2
║⍆║ ➲ ${Prefix}Akinator
║⍆║ ➲ ${Prefix}Jogodaforca
║⍆║ ➲ ${Prefix}Forca [letra]
║⍆║ ➲ ${Prefix}Resetforca
║⍆║ ➲ ${Prefix}Jogar @553175.... [pedra papel tesoura]
║⍆║ ➲ ${Prefix}Aqua [pergunte algo]
║⍆║ ➲ ${Prefix}Fazernick
║⍆║ ➲ ${Prefix}Pau
║⍆║ ➲ ${Prefix}Gay1
║⍆║ ➲ ${Prefix}Gadometro
║⍆║ ➲ ${Prefix}Chance [pergunte algo]
║⍆║ ➲ ${Prefix}Cassino
║⍆║ ➲ ${Prefix}Casal
║⍆║ ➲ ${Prefix}Shipo
║⍆║ ➲ ${Prefix}Alma-Gemeas
║⍆║ ➲ ${Prefix}Duelo
║⍆║ ➲ ${Prefix}Feio
║⍆║ ➲ ${Prefix}Matar
║⍆║ ➲ ${Prefix}Gay
║⍆║ ➲ ${Prefix}Vesgo
║⍆║ ➲ ${Prefix}Bebado
║⍆║ ➲ ${Prefix}Gado
║⍆║ ➲ ${Prefix}Gostoso
║⍆║ ➲ ${Prefix}Gostosa
║⍆║ ➲ ${Prefix}Beijo
║⍆║ ➲ ${Prefix}Tapa
║⍆║ ➲ ${Prefix}Chutar
║⍆║ ➲ ${Prefix}Dogolpe
║⍆║ ➲ ${Prefix}Nazista 
║⍆║ ➲ ${Prefix}RankGay
║⍆║ ➲ ${Prefix}RankGado
║⍆║ ➲ ${Prefix}RankCorno
║⍆║ ➲ ${Prefix}RankGostosos
║⍆║ ➲ ${Prefix}RankGostosas
║⍆║ ➲ ${Prefix}Ranknazista
║⍆║ ➲ ${Prefix}Rankotakus
║⍆║ ➲ ${Prefix}Rankpau
║⍆║ ➲ ${Prefix}Quando
║⍆║ ➲ ${Prefix}SN [fale algo]
║⍆║ ➲ ${Prefix}Pix [número/valor]
║⍆║ ➲ ${Prefix}Tagme
║⍆║ 
║⍆
╰─╼━━━══━━━≺💧≻━━━══━━━╾─╯`
}

exports.brincadeiras = brincadeiras
